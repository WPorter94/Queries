William Porter

BreakDown-
	Bm25 scoring occurs in function bm25()
	ql scoring occurs in function ql()
	evaluateQuery() function handles the breaking down each query line
	evaluateDoc() function handles most of the information retrieval for the document
Description-
	query.py is responsible for taking in a document of queries and retiurning score values for each document based
	off query specifications(scoring type, terms for scoring). For this project I decided to return multiple
	python dictionaries from evaluateDoc() that contain almost all the required information needed for each term 
	and document in the collection. This allowed for easy information retrieval based of term or scene number in the 
	rest of my program.
Libraries-
	os - used for checking if results file already exists in directory.
	sys - used to retrive command line arguments
	gzip - used to access data in .gz file
	json - used to load json data  from file
	csv  - used to read .tsv file
	time - used to calculate each queries time to run
	math - used to find logarithm
Dependencies- 
	-
Building/ running-
	on command line "python query.py collection.json.gz queries.tsv outputFIle"
	where collection.json.gz is the document collection
	queries.tsv are the given queries
	output fiel is any .txt filew  to be written to.

	